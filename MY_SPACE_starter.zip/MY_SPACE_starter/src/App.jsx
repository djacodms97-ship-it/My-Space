import { useEffect, useMemo, useState } from "react";
import { supabase, supabaseReady } from "./supabase";
import { Wallet, CalendarDays, Bookmark, LayoutDashboard, LogOut, Plus, Check, Trash2 } from "lucide-react";

const money = n => new Intl.NumberFormat("ko-KR").format(Number(n || 0)) + "원";
const today = () => new Date().toISOString().slice(0,10);

export default function App() {
  const [session, setSession] = useState(null);
  const [tab, setTab] = useState("home");
  const [expenses, setExpenses] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({ title:"", amount:"", category:"생활", date:today(), type:"지출", url:"", note:"", due_date:today() });

  useEffect(() => {
    if (!supabaseReady) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => { if (session) loadAll(); }, [session]);

  async function loadAll() {
    setLoading(true);
    const uid = session.user.id;
    const [e,t,l] = await Promise.all([
      supabase.from("expenses").select("*").eq("user_id",uid).order("date",{ascending:false}),
      supabase.from("tasks").select("*").eq("user_id",uid).order("created_at",{ascending:false}),
      supabase.from("saved_links").select("*").eq("user_id",uid).order("created_at",{ascending:false})
    ]);
    if (!e.error) setExpenses(e.data || []);
    if (!t.error) setTasks(t.data || []);
    if (!l.error) setLinks(l.data || []);
    setLoading(false);
  }

  async function authenticate(ev) {
    ev.preventDefault(); setMessage("");
    const fn = authMode === "login" ? supabase.auth.signInWithPassword : supabase.auth.signUp;
    const { error } = await fn({ email, password });
    setMessage(error ? error.message : (authMode === "login" ? "로그인했어요." : "가입 확인 메일을 확인해 주세요."));
  }

  async function addExpense(ev) {
    ev.preventDefault();
    const { error } = await supabase.from("expenses").insert({
      user_id:session.user.id, title:form.title, amount:Number(form.amount),
      category:form.category, date:form.date, note:form.note
    });
    if (error) setMessage(error.message); else { setForm({...form,title:"",amount:"",note:""}); loadAll(); }
  }
  async function addTask(ev) {
    ev.preventDefault();
    const { error } = await supabase.from("tasks").insert({
      user_id:session.user.id, title:form.title, due_date:form.due_date, description:form.note
    });
    if (error) setMessage(error.message); else { setForm({...form,title:"",note:""}); loadAll(); }
  }
  async function addLink(ev) {
    ev.preventDefault();
    const { error } = await supabase.from("saved_links").insert({
      user_id:session.user.id, title:form.title, url:form.url, category:form.category, note:form.note
    });
    if (error) setMessage(error.message); else { setForm({...form,title:"",url:"",note:""}); loadAll(); }
  }
  async function remove(table,id) {
    const { error } = await supabase.from(table).delete().eq("id",id);
    if (error) setMessage(error.message); else loadAll();
  }
  async function toggleTask(item) {
    const { error } = await supabase.from("tasks").update({is_done:!item.is_done}).eq("id",item.id);
    if (error) setMessage(error.message); else loadAll();
  }

  const monthExpenses = useMemo(() => expenses.filter(x => x.date?.slice(0,7) === today().slice(0,7)), [expenses]);
  const total = monthExpenses.reduce((s,x) => s + Number(x.amount || 0),0);

  if (!supabaseReady) return <main className="setup"><div className="brand">MY SPACE</div><h1>나만의 공간을 준비하고 있어요</h1><p>아직 Supabase 연결 정보가 설정되지 않았어요.</p><p>제작 안내서의 .env 설정 단계에서 Project URL과 publishable key를 입력해야 해요.</p></main>;
  if (!session) return <main className="auth"><div className="brand">MY SPACE</div><p className="sub">YOUR PERSONAL SPACE</p><form onSubmit={authenticate} className="panel"><h1>{authMode === "login" ? "다시 만나서 반가워요" : "계정 만들기"}</h1><label>이메일<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>비밀번호<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength="6" required /></label><button className="primary">{authMode === "login" ? "로그인" : "가입하기"}</button><button type="button" className="textbtn" onClick={()=>setAuthMode(authMode==="login"?"signup":"login")}>{authMode==="login"?"처음이신가요? 회원가입":"이미 계정이 있나요? 로그인"}</button>{message && <p className="message">{message}</p>}</form></main>;

  return <div className="app">
    <header><div><div className="brand">MY SPACE</div><div className="sub">YOUR PERSONAL DASHBOARD</div></div><button className="iconbtn" onClick={()=>supabase.auth.signOut()} aria-label="로그아웃"><LogOut size={18}/></button></header>
    <main>
      {tab==="home" && <><section className="welcome"><p className="eyebrow">MY DASHBOARD</p><h1>나의 하루를<br/>차분하게 정리해요</h1><p>기록하고, 계획하고, 모아두는 나만의 공간</p></section><div className="stats"><article><span>이번 달 기록 합계</span><strong>{money(total)}</strong><small>수입·지출 기록 기준</small></article><article><span>남은 할 일</span><strong>{tasks.filter(x=>!x.is_done).length}개</strong><small>완료 전 항목</small></article></div><section className="panel"><h2>최근 지출 기록</h2>{expenses.slice(0,3).map(x=><div className="item" key={x.id}><div><b>{x.title}</b><small>{x.category} · {x.date}</small></div><strong>{money(x.amount)}</strong></div>)}{!expenses.length&&<p className="empty">아직 기록이 없어요. 첫 기록을 추가해 보세요.</p>}</section></>}
      {tab==="expenses" && <><h1>수입·지출</h1><form className="panel form" onSubmit={addExpense}><h2>새 기록</h2><input placeholder="내용" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/><input type="number" placeholder="금액" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} required/><div className="two"><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>생활</option><option>식비</option><option>교통</option><option>쇼핑</option><option>급여</option><option>기타</option></select><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div><button className="primary"><Plus size={16}/> 기록 추가</button></form><section className="panel">{expenses.map(x=><div className="item" key={x.id}><div><b>{x.title}</b><small>{x.category} · {x.date}</small></div><strong>{money(x.amount)}</strong><button className="tiny" onClick={()=>remove("expenses",x.id)}><Trash2 size={15}/></button></div>)}{!expenses.length&&<p className="empty">저장된 기록이 없어요.</p>}</section></>}
      {tab==="tasks" && <><h1>일정·할 일</h1><form className="panel form" onSubmit={addTask}><h2>새 할 일</h2><input placeholder="무엇을 할까요?" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/><input type="date" value={form.due_date} onChange={e=>setForm({...form,due_date:e.target.value})}/><button className="primary"><Plus size={16}/> 추가하기</button></form><section className="panel">{tasks.map(x=><div className="item" key={x.id}><button className="tiny" onClick={()=>toggleTask(x)}>{x.is_done?<Check size={16}/>:<span className="circle"/>}</button><div className={x.is_done?"done":""}><b>{x.title}</b><small>{x.due_date || "날짜 미정"}</small></div><button className="tiny" onClick={()=>remove("tasks",x.id)}><Trash2 size={15}/></button></div>)}{!tasks.length&&<p className="empty">등록된 일정이 없어요.</p>}</section></>}
      {tab==="links" && <><h1>링크 보관함</h1><form className="panel form" onSubmit={addLink}><h2>링크 저장</h2><input placeholder="이름 또는 제목" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} required/><input type="url" placeholder="https://..." value={form.url} onChange={e=>setForm({...form,url:e.target.value})} required/><input placeholder="분류" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}/><input placeholder="메모 (선택)" value={form.note} onChange={e=>setForm({...form,note:e.target.value})}/><button className="primary"><Plus size={16}/> 링크 저장</button></form><section className="panel">{links.map(x=><div className="item" key={x.id}><div><b>{x.title}</b><small>{x.category}</small><a href={x.url} target="_blank" rel="noreferrer">{x.url}</a></div><button className="tiny" onClick={()=>remove("saved_links",x.id)}><Trash2 size={15}/></button></div>)}{!links.length&&<p className="empty">저장된 링크가 없어요.</p>}</section></>}
      {message && <p className="message">{message}</p>}
      {loading && <p className="empty">불러오는 중…</p>}
    </main>
    <nav>{[["home",LayoutDashboard,"홈"],["expenses",Wallet,"가계부"],["tasks",CalendarDays,"일정"],["links",Bookmark,"링크"]].map(([id,Icon,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><Icon size={19}/><span>{label}</span></button>)}</nav>
  </div>;
}
