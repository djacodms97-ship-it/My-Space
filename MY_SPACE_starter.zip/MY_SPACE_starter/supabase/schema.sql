create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  amount numeric not null default 0,
  category text,
  date date not null default current_date,
  note text,
  created_at timestamptz default now()
);
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  due_date date,
  is_done boolean not null default false,
  created_at timestamptz default now()
);
create table if not exists public.saved_links (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  url text not null,
  category text,
  note text,
  created_at timestamptz default now()
);
alter table public.expenses enable row level security;
alter table public.tasks enable row level security;
alter table public.saved_links enable row level security;
drop policy if exists "Users manage own expenses" on public.expenses;
drop policy if exists "Users manage own tasks" on public.tasks;
drop policy if exists "Users manage own saved links" on public.saved_links;
create policy "Users manage own expenses" on public.expenses for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own tasks" on public.tasks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own saved links" on public.saved_links for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
